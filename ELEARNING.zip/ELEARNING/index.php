<?php 
header('location:E-learning/login.php');

?>